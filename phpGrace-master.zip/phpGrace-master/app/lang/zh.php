<?php
return array(
	'APP_NAME'     => 'phpGrace',
);
<?php
include 'phpGrace/phpGrace.php';